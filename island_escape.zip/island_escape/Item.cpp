// FILE: Item.cpp
#include "Item.h"


Item::Item(std::string id, std::string name, std::string desc, bool consumable)
: _id(std::move(id)), _name(std::move(name)), _desc(std::move(desc)), _consumable(consumable) {}


const std::string& Item::id() const { return _id; }
const std::string& Item::name() const { return _name; }
const std::string& Item::description() const { return _desc; }
bool Item::isConsumable() const { return _consumable; }