#ifndef ISLAND_H
#define ISLAND_H

#include <vector>
#include <string>
#include <memory>

// Forward declaration of Item class
class Item;

class Location {
public:
    std::string id;
    std::string name;
    std::string description;
    std::vector<std::shared_ptr<Item>> items;

    Location(const std::string& id, const std::string& name, const std::string& description);
};

class Island {
public:
    std::vector<Location> locations;

    Island();
};

#endif
