#ifndef PLAYER_H
#define PLAYER_H


#include <string>
#include <vector>
#include <memory>


class Item;


class Player {
public:
Player(std::string name="Castaway");


void setLocation(const std::string& loc);
const std::string& location() const;


void addItem(std::shared_ptr<Item> item);
bool hasItem(const std::string& id) const;
std::shared_ptr<Item> takeItem(const std::string& id);
void listInventory() const;


int health() const;
void changeHealth(int delta);


private:
std::string _name;
std::string _location;
int _health{100};
std::vector<std::shared_ptr<Item>> _inventory;
};


#endif // PLAYER_H